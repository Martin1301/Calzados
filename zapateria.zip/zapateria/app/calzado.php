<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class calzado extends Model
{
 protected $table='calzado';
 
 protected $primaryKey = 'idcalzado';

 protected $fillable =  array('calzado', 'tipo', 'color', 'talla','marca','genero','edades');

 protected $hidden = ['created_at','updated_at'];
}
