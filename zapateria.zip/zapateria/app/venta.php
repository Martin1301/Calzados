<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class venta extends Model
{
 protected $table='venta';
 
 protected $primaryKey = 'idventa';

 protected $fillable =  array('calzado', 'tipo', 'color', 'talla','fecha_compra', 'tipo_pago', 'monto_pago');

 protected $hidden = ['created_at','updated_at'];
}
