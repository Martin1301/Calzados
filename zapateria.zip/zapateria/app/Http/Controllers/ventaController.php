<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\venta;
use App\calzado;

class ventaController extends Controller
{
    /**
    * Muestra una lista de las ventas.
    *
    * @return Response
    */
    public function index()
    {
      // Devolverá todos las ventas
      $vendidos = venta::get();
      return view('ventas.index')->with('vendidos', $vendidos);
    }
        /**
   * Muestra el vendido seleccionada por id.
   * @param $idventa 
   * @return Response
   */
    public function show($idventa)
    {
      // Devuelve la venta seleccionada por id.
      $vendido = venta::find($idventa);
      return view('ventas.show')->with('vendido', $vendido);
    }

    public function destroy($idventa)
    {
      venta::destroy($idventa);
      return redirect('ventas')->with('success','Venta eliminada satisfactoriamente');
    }

    public function edit($idventa)
  {
    $vendido = venta::findOrFail($idventa);
    return view('ventas.edit',compact('vendido'));
  }

    public function update(Request $request,$idventa)
  {
    $vendido=venta::findOrFail($idventa);
    $vendido->calzado=$request->input('calzado');
    $vendido->tipo=$request->input('tipo');
    $vendido->color=$request->input('color');
    $vendido->talla=$request->input('talla');
    $vendido->fecha_compra=$request->input('fecha_compra');
    $vendido->tipo_pago=$request->input('tipo_pago');
    $vendido->monto_pago=$request->input('monto_pago');
    $vendido->save();
    return redirect()->route('ventas.index');
  }

    public function create()
    {
    return view('ventas.comprar');
    }

    public function store(Request $request)
  {
    $vendido = new venta;
    $vendido->calzado=$request->input('calzado');
    $vendido->tipo=$request->input('tipo');
    $vendido->color=$request->input('color');
    $vendido->talla=$request->input('talla');
    $vendido->fecha_compra=$request->input('fecha_compra');
    $vendido->tipo_pago=$request->input('tipo_pago');
    $vendido->monto_pago=$request->input('monto_pago');
    $vendido->save();
    return redirect()->route('ventas.index');
  }

}
