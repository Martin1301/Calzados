<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\calzado;
class calzadoController extends Controller
{
    /**
    * Muestra una lista de los zapatos.
    *
    * @return Response
    */
    public function index()
    {
      // Devolverá todos los zapatos
      $zapatos = calzado::get();
      return view('zapatos.index')->with('zapatos', $zapatos);
    }
    /**
   * Muestra el zapato seleccionada por id.
   * @param $idcalzado 
   * @return Response
   */
    public function show($idcalzado)
    {
      // Devuelve la zapato seleccionada por id.
      $zapato = calzado::find($idcalzado);
      return view('zapatos.show')->with('zapato', $zapato);
    }

    public function destroy($idcalzado)
  {
    calzado::destroy($idcalzado);
    return redirect('zapatos')->with('success','Registro eliminado satisfactoriamente');
  }

  public function edit($idcalzado)
  {
    $zapato = calzado::findOrFail($idcalzado);
    return view('zapatos.edit',compact('zapato'));
  }

  public function update(Request $request,$idcalzado)
  {
    $zapato=calzado::findOrFail($idcalzado);
    $zapato->calzado=$request->input('calzado');
    $zapato->tipo=$request->input('tipo');
    $zapato->color=$request->input('color');
    $zapato->talla=$request->input('talla');
    $zapato->marca=$request->input('marca');
    $zapato->genero=$request->input('genero');
    $zapato->edades=$request->input('edades');
    $zapato->save();
    return redirect()->route('zapatos.index');
  }

  public function create()
  {
    return view('zapatos.create');
  }

  public function store(Request $request)
  {
    $zapato = new calzado;
    $zapato->calzado=$request->input('calzado');
    $zapato->tipo=$request->input('tipo');
    $zapato->color=$request->input('color');
    $zapato->talla=$request->input('talla');
    $zapato->marca=$request->input('marca');
    $zapato->genero=$request->input('genero');
    $zapato->edades=$request->input('edades');
    $zapato->save();
    return redirect()->route('zapatos.index');
  }
}
