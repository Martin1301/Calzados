@extends('app')
@section('content')
<h1>
  Calzado {{ $zapato->calzado}}
</h1>
 
<p>Id calzado: {{ $zapato->idcalzado}}</p>
<p>Calzado: {{ $zapato->calzado}}</p>
<p>Tipo: {{ $zapato->tipo}}</p>
<p>Color: {{ $zapato->color}}</p>
<p>Talla: {{ $zapato->talla}}</p>
<p>Marca: {{ $zapato->marca}}</p>
<p>Género: {{ $zapato->genero}}</p>
<p>Edades: {{ $zapato->edades}}</p>
<hr>
 
<a href="{{ route('zapatos.index')}}" class="btn btn-info btn-sm">Volver al índice</a>
<a href="{{ route('ventas.create')}}" class="btn btn-success btn-sm">Realizar compra</a>
<div>
@stop