@extends('app')
@section('content')
<h1 class="text-primary">Lista de ventas</h1>
 
<table class="table table-bordered" id="tableventas">
  <thead>
    <tr>
        <th class="text-center">Id venta</th>
        <th class="text-center">Fecha compra</th>
        <th class="text-center">Tipo pago</th>
        <th class="text-center">Monto pago</th>
        <th class="text-center">Ver</th>
        <th class="text-center">Borrar</th>
        <th class="text-center">Editar</th>

    </tr>
  </thead>
  <tbody>
    @foreach($vendidos as $venta)
        <tr>
            <td class="text-center">{{ $venta->idventa}}</td>
            <td class="text-center">{{ $venta->fecha_compra}}</td>
            <td class="text-center">{{ $venta->tipo_pago }}</td>
            <td class="text-center">{{ $venta->monto_pago}}</td>
            <td class="text-center">
                <a href="{{route('ventas.show', $venta->idventa)}}"class="btn btn-info btn-sm">
                <span class="glyphicon glyphicon-eye-open"></span></a>
            </td>
            <td class="text-center">
                <form action="{{url('/ventas/'.$venta->idventa)}}" method="post" >
                @csrf
                {{method_field('DELETE')}}
                <input name="_method" type="hidden" value="DELETE">
                <button class="btn btn-danger btn-sm" type="submit"><span class="glyphicon
                glyphicon-trash"></span></button>
                </form>
            </td>
            <td class="text-center">
              <a href="{{route('ventas.edit',$venta->idventa)}}"class="btn btn-warning btn-sm">
                <span class="glyphicon glyphicon-pencil"></span></a>
            </td>
        </tr>
    @endforeach
  </tbody>
  <tfoot>
    <tr>
      <th class="text-center">Id venta</th>
      <th class="text-center">Fecha compra</th>
      <th class="text-center">Tipo pago</th>
      <th class="text-center">Monto pago</th>
      <th class="text-center">Ver</th>
      <th class="text-center">Borrar</th>
      <th class="text-center">Editar</th>
    </tr>
  </tfoot>
</table>
@stop