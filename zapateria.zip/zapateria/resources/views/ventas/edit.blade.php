@extends('app')
@section('content')
<h2>Editar venta</h2>
<table class="container-row">
<form action="{{route('ventas.update',$vendido->idventa)}}" method="post">
    @csrf
    @method('PUT')
    <div class="form-group">
        <label for="calzado">Calzado</label>
        <input type="text" class="form-control" name="calzado" required value="{{$vendido->calzado}}">
    </div>
    <div class="form-group">
        <label for="tipo">Tipo</label>
        <input type="text" class="form-control"  name="tipo" required value="{{$vendido->tipo}}">
    </div>
    <div class="form-group">
        <label for="color">Color</label>
        <input type="text" class="form-control"  name="color" required value="{{$vendido->color}}">
    </div>
    <div class="form-group">
        <label for="talla">Talla</label>
        <input type="text" class="form-control"  name="talla" required value="{{$vendido->talla}}">
    </div>
    <div class="form-group">
        <label for="fecha_compra">Fecha compra</label>
        <input type="date" class="form-control"  name="fecha_compra" required value="{{$vendido->fecha_compra}}">
    </div>
    <div class="form-group">
        <label for="tipo_pago">Tipo pago</label>
        <input type="text" class="form-control"  name="tipo_pago" required value="{{$vendido->tipo_pago}}">
    </div>
    <div class="form-group">
        <label for="monto_pago">Monto pago</label>
        <input type="text" class="form-control"  name="monto_pago" required value="{{$vendido->monto_pago}}">
    </div>
    <div class="text-right">
    <button type="submit" class="btn btn-primary mr-5">Actualizar venta</button>
    <button type="reset" class="btn btn-danger mr-5" value="cancelar">Cancelar</button>
    <a href="javascript:history.back()" class="btn btn-default btn-sm">Listado</a>
    </div>
</table>
<br>
@stop