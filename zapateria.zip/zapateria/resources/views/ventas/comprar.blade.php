@extends('app')
@section('content')
<h2>Especificar Compra</h2>
<table class="container-row">
<form action="{{route('ventas.store')}}" method="post">
    @csrf
    <div class="form-group">
        <label for="calzado">Calzado</label>
        <input type="text" class="form-control" placeholder="zapato"  name="calzado" required>
    </div>
    <div class="form-group">
        <label for="tipo">Tipo</label>
        <input type="text" class="form-control" placeholder="Naúticos" name="tipo" required >
    </div>
    <div class="form-group">
        <label for="color">Color</label>
        <input type="text" class="form-control" placeholder="Timberland" name="color" required >
    </div>
    <div class="form-group">
        <label for="talla">Talla</label>
        <input type="text" class="form-control" placeholder="38,40" name="talla" required>
    </div>
    <div class="form-group">
        <label for="fecha_compra">Fecha compra</label>
        <input type="date" class="form-control" placeholder="2021/02/24" name="fecha_compra" required>
    </div>
    <div class="form-group">
        <label for="tipo_pago">Tipo pago</label>
        <input type="text" class="form-control" placeholder="Efectivo" name="tipo_pago" required>
    </div>
    <div class="form-group">
        <label for="monto_pago">Monto pago</label>
        <input type="text" class="form-control" placeholder="189" name="monto_pago" required>
    </div>
    <div class="text-right">
    <button type="submit" class="btn btn-primary mr-5">Realizar compra</button>
    <button type="reset" class="btn btn-danger mr-5" value="cancelar">Cancelar</button>
    <a href="javascript:history.back()" class="btn btn-default btn-sm">Listado</a>
    </div>
</table>
<br>
@stop