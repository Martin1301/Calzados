@extends('app')
@section('content')
<h1>
Compra de {{ $vendido->calzado}}
</h1>

<p>Id venta: {{ $vendido->idventa}}</p>
<p>Calzado: {{ $vendido->calzado}}</p>
<p>Tipo: {{ $vendido->tipo}}</p>
<p>Color: {{ $vendido->color}}</p>
<p>Talla: {{ $vendido->talla}}</p>
<p>Fecha compra: {{ $vendido->fecha_compra}}</p>
<p>Tipo pago: {{ $vendido->tipo_pago}}</p>
<p>Monto: {{ $vendido->monto_pago}}</p>

<hr>
<a href="{{ route('ventas.index')}}" class="btn btn-info btn-sm">Volver al índice</a>
<div>
@stop