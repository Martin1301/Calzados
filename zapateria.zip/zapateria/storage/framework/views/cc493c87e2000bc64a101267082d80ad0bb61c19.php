
<?php $__env->startSection('content'); ?>
<h2>Agregar Calzado</h2>
<table class="container-row">
<form action="<?php echo e(route('zapatos.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="calzado">Calzado</label>
        <input type="text" class="form-control" placeholder="zapato" name="calzado" required >
    </div>
    <div class="form-group">
        <label for="tipo">Tipo</label>
        <input type="text" class="form-control" placeholder="Naúticos" name="tipo" required >
    </div>
    <div class="form-group">
        <label for="color">Color</label>
        <input type="text" class="form-control" placeholder="Negro" name="color" required >
    </div>
    <div class="form-group">
        <label for="talla">Talla</label>
        <input type="text" class="form-control" placeholder="38,40" name="talla" required>
    </div>
    <div class="form-group">
        <label for="marca">Marca</label>
        <input type="text" class="form-control" placeholder="Timberland" name="marca" required>
    </div>
    <div class="form-group">
        <label for="genero">Género</label>
        <input type="text" class="form-control" placeholder="M" name="genero" required>
    </div>
    <div class="form-group">
        <label for="edades">Edad</label>
        <input type="text" class="form-control" placeholder="20-25" name="edades" required>
    </div>
    <div class="text-right">
    <button type="submit" class="btn btn-primary mr-5">Agregar datos</button>
    <button type="reset" class="btn btn-danger mr-5" value="cancelar">Cancelar</button>
    <a href="javascript:history.back()" class="btn btn-default btn-sm">Listado</a>
    </div>
</table>
<br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Desarrollo de aplicaciones en Internet\Sem12\zapateria\resources\views/zapatos/create.blade.php ENDPATH**/ ?>