
<?php $__env->startSection('content'); ?>
<h1 class="text-primary">Lista de calzados</h1>
 
<table class="table table-bordered" id="tablecalzado">
  <thead>
    <tr>
        <th class="text-center">Id Calzado</th>
        <th class="text-center">Calzado</th>
        <th class="text-center">Tipo</th>
        <th class="text-center">Color</th>
        <th class="text-center">Ver</th>
        <th class="text-center">Borrar</th>
        <th class="text-center">Editar</th>
    </tr >
  </thead>
  <tbody>
    <?php $__currentLoopData = $zapatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zapato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($zapato->idcalzado); ?></td>
            <td class="text-center"><?php echo e($zapato->calzado); ?></td>
            <td class="text-center"><?php echo e($zapato->tipo); ?></td>
            <td class="text-center"><?php echo e($zapato->color); ?></td>
            <td class="text-center">
                <a href="<?php echo e(route('zapatos.show', $zapato->idcalzado)); ?>"class="btn btn-info btn-sm">
                <span class="glyphicon glyphicon-eye-open"></span></a>
            </td>
            <td class="text-center">
                <form action="<?php echo e(url('/zapatos/'.$zapato->idcalzado)); ?>" method="post" >
                <?php echo csrf_field(); ?>
                <?php echo e(method_field('DELETE')); ?>

                <input name="_method" type="hidden" value="DELETE">
                <button class="btn btn-danger btn-sm" type="submit"><span class="glyphicon
                glyphicon-trash"></span></button>
                </form>
            </td>
            <td class="text-center">
              <a href="<?php echo e(route('zapatos.edit',$zapato->idcalzado)); ?>"class="btn btn-warning btn-sm">
                <span class="glyphicon glyphicon-pencil"></span></a>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
  <tfoot>
    <tr>
      <th class="text-center">Id Calzado</th>
      <th class="text-center">Calzado</th>
      <th class="text-center">Tipo</th>
      <th class="text-center">Color</th>  
      <th class="text-center">ver</th>
      <th class="text-center">Borrar</th>
      <th class="text-center">Editar</th> 
    </tr>
  </tfoot>
</table>
<div class="text-right">
<a href="<?php echo e(route('zapatos.create')); ?>" class="btn btn-success mr-5">Nuevo calzado</a>
<div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Desarrollo de aplicaciones en Internet\Sem12\zapateria\resources\views/zapatos/index.blade.php ENDPATH**/ ?>