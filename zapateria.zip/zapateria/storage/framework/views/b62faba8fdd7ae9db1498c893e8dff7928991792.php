
<?php $__env->startSection('content'); ?>
<h1>
  Calzado <?php echo e($zapato->calzado); ?>

</h1>
 
<p>Id calzado: <?php echo e($zapato->idcalzado); ?></p>
<p>Calzado: <?php echo e($zapato->calzado); ?></p>
<p>Tipo: <?php echo e($zapato->tipo); ?></p>
<p>Color: <?php echo e($zapato->color); ?></p>
<p>Talla: <?php echo e($zapato->talla); ?></p>
<p>Marca: <?php echo e($zapato->marca); ?></p>
<p>Género: <?php echo e($zapato->genero); ?></p>
<p>Edades: <?php echo e($zapato->edades); ?></p>
<hr>
 
<a href="<?php echo e(route('zapatos.index')); ?>" class="btn btn-info btn-sm">Volver al índice</a>
<a href="<?php echo e(route('ventas.create')); ?>" class="btn btn-success btn-sm">Realizar compra</a>
<div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Desarrollo de aplicaciones en Internet\Sem12\zapateria\resources\views/zapatos/show.blade.php ENDPATH**/ ?>