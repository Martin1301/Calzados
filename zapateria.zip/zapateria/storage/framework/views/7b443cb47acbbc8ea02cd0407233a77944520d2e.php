
<?php $__env->startSection('content'); ?>
<h1 class="text-primary">Lista de ventas</h1>
 
<table class="table table-bordered" id="tableventas">
  <thead>
    <tr>
        <th class="text-center">Id venta</th>
        <th class="text-center">Fecha compra</th>
        <th class="text-center">Tipo pago</th>
        <th class="text-center">Monto pago</th>
        <th class="text-center">Ver</th>
        <th class="text-center">Borrar</th>
        <th class="text-center">Editar</th>

    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $vendidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($venta->idventa); ?></td>
            <td class="text-center"><?php echo e($venta->fecha_compra); ?></td>
            <td class="text-center"><?php echo e($venta->tipo_pago); ?></td>
            <td class="text-center"><?php echo e($venta->monto_pago); ?></td>
            <td class="text-center">
                <a href="<?php echo e(route('ventas.show', $venta->idventa)); ?>"class="btn btn-info btn-sm">
                <span class="glyphicon glyphicon-eye-open"></span></a>
            </td>
            <td class="text-center">
                <form action="<?php echo e(url('/ventas/'.$venta->idventa)); ?>" method="post" >
                <?php echo csrf_field(); ?>
                <?php echo e(method_field('DELETE')); ?>

                <input name="_method" type="hidden" value="DELETE">
                <button class="btn btn-danger btn-sm" type="submit"><span class="glyphicon
                glyphicon-trash"></span></button>
                </form>
            </td>
            <td class="text-center">
              <a href="<?php echo e(route('ventas.edit',$venta->idventa)); ?>"class="btn btn-warning btn-sm">
                <span class="glyphicon glyphicon-pencil"></span></a>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
  <tfoot>
    <tr>
      <th class="text-center">Id venta</th>
      <th class="text-center">Fecha compra</th>
      <th class="text-center">Tipo pago</th>
      <th class="text-center">Monto pago</th>
      <th class="text-center">Ver</th>
      <th class="text-center">Borrar</th>
      <th class="text-center">Editar</th>
    </tr>
  </tfoot>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Desarrollo de aplicaciones en Internet\Sem12\zapateria\resources\views/ventas/index.blade.php ENDPATH**/ ?>