
<?php $__env->startSection('content'); ?>
<h2>Editar registro</h2>
<table class="container-row">
<form action="<?php echo e(route('zapatos.update',$zapato->idcalzado)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="form-group">
        <label for="calzado">Calzado</label>
        <input type="text" class="form-control" name="calzado" required value="<?php echo e($zapato->calzado); ?>">
    </div>
    <div class="form-group">
        <label for="tipo">Tipo</label>
        <input type="text" class="form-control" name="tipo" required value="<?php echo e($zapato->tipo); ?>">
    </div>
    <div class="form-group">
        <label for="color">Color</label>
        <input type="text" class="form-control" name="color" required value="<?php echo e($zapato->color); ?>">
    </div>
    <div class="form-group">
        <label for="talla">Talla</label>
        <input type="text" class="form-control" name="talla" required value="<?php echo e($zapato->talla); ?>">
    </div>
    <div class="form-group">
        <label for="marca">Marca</label>
        <input type="text" class="form-control" name="marca" required value="<?php echo e($zapato->marca); ?>">
    </div>
    <div class="form-group">
        <label for="genero">Género</label>
        <input type="text" class="form-control" name="genero" required value="<?php echo e($zapato->genero); ?>">
    </div>
    <div class="form-group">
        <label for="edades">Edad</label>
        <input type="text" class="form-control" name="edades" required value="<?php echo e($zapato->edades); ?>">
    </div>
    <div class="text-right">
    <button type="submit" class="btn btn-primary mr-5">Guardar datos</button>
    <button type="reset" class="btn btn-danger mr-5" value="cancelar">Cancelar</button>
    <a href="javascript:history.back()" class="btn btn-default btn-sm">Listado</a>
    </div>
</table>
<br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Desarrollo de aplicaciones en Internet\Sem12\zapateria\resources\views/zapatos/edit.blade.php ENDPATH**/ ?>