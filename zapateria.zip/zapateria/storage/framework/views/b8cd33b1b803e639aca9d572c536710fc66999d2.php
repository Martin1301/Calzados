
<?php $__env->startSection('content'); ?>
<h1>
Compra de <?php echo e($vendido->calzado); ?>

</h1>

<p>Id venta: <?php echo e($vendido->idventa); ?></p>
<p>Calzado: <?php echo e($vendido->calzado); ?></p>
<p>Tipo: <?php echo e($vendido->tipo); ?></p>
<p>Color: <?php echo e($vendido->color); ?></p>
<p>Talla: <?php echo e($vendido->talla); ?></p>
<p>Fecha compra: <?php echo e($vendido->fecha_compra); ?></p>
<p>Tipo pago: <?php echo e($vendido->tipo_pago); ?></p>
<p>Monto: <?php echo e($vendido->monto_pago); ?></p>

<hr>
<a href="<?php echo e(route('ventas.index')); ?>" class="btn btn-info btn-sm">Volver al índice</a>
<div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Desarrollo de aplicaciones en Internet\Sem12\zapateria\resources\views/ventas/show.blade.php ENDPATH**/ ?>