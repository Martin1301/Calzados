
<?php $__env->startSection('content'); ?>
<h2>Editar venta</h2>
<table class="container-row">
<form action="<?php echo e(route('ventas.update',$vendido->idventa)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="form-group">
        <label for="calzado">Calzado</label>
        <input type="text" class="form-control" name="calzado" required value="<?php echo e($vendido->calzado); ?>">
    </div>
    <div class="form-group">
        <label for="tipo">Tipo</label>
        <input type="text" class="form-control"  name="tipo" required value="<?php echo e($vendido->tipo); ?>">
    </div>
    <div class="form-group">
        <label for="color">Color</label>
        <input type="text" class="form-control"  name="color" required value="<?php echo e($vendido->color); ?>">
    </div>
    <div class="form-group">
        <label for="talla">Talla</label>
        <input type="text" class="form-control"  name="talla" required value="<?php echo e($vendido->talla); ?>">
    </div>
    <div class="form-group">
        <label for="fecha_compra">Fecha compra</label>
        <input type="date" class="form-control"  name="fecha_compra" required value="<?php echo e($vendido->fecha_compra); ?>">
    </div>
    <div class="form-group">
        <label for="tipo_pago">Tipo pago</label>
        <input type="text" class="form-control"  name="tipo_pago" required value="<?php echo e($vendido->tipo_pago); ?>">
    </div>
    <div class="form-group">
        <label for="monto_pago">Monto pago</label>
        <input type="text" class="form-control"  name="monto_pago" required value="<?php echo e($vendido->monto_pago); ?>">
    </div>
    <div class="text-right">
    <button type="submit" class="btn btn-primary mr-5">Actualizar venta</button>
    <button type="reset" class="btn btn-danger mr-5" value="cancelar">Cancelar</button>
    <a href="javascript:history.back()" class="btn btn-default btn-sm">Listado</a>
    </div>
</table>
<br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Desarrollo de aplicaciones en Internet\Sem12\zapateria\resources\views/ventas/edit.blade.php ENDPATH**/ ?>